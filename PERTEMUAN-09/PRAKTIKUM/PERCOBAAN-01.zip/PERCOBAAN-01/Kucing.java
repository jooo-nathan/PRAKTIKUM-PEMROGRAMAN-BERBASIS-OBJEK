// package PERTEMUAN-09.PRAKTIKUM.PERCOBAAN-01;

public class Kucing extends Hewan {
    public void bergerak() {
        System.out.println("Berjalan dengan KAKI, \"tap..tap..\"");
    }
}
